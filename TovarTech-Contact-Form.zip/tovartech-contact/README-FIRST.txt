TOVAR TECH CONTACT FORM PACKAGE
===============================
Website: https://tovartech.org
Destination email: noetovar5@gmail.com

WHAT IS INCLUDED
----------------
contact.html                 Public contact page
send-contact.php             Secure server-side form processor
setup-contact.sh             Ubuntu setup/install script
contact-config.php.example   Example only -- never put your real password here
.htaccess                    Basic Apache security settings
README-FIRST.txt             This file

IMPORTANT
---------
The form uses Gmail SMTP. Your normal Gmail password should NEVER be placed in
contact.html or send-contact.php. Use a Google App Password. The setup script
stores it outside the public website directory in:

/etc/tovartech/contact-config.php

The script also installs php-mbstring. This prevents the mb_strlen() HTTP 500
problem that can occur when the PHP mbstring module is missing.

INSTALLATION
------------
1. Extract this ZIP on your Windows PC.

2. In WinSCP, upload ALL files inside the tovartech-contact folder into the
   document root for TovarTech.org -- the same folder that contains the site's
   index.html. Common examples are:

   /var/www/tovartech.org/html/
   /var/www/tovartech/
   /var/www/html/

   Use YOUR actual TovarTech Apache document root.

3. SSH into the Ubuntu server and change into that website directory. Example:

   cd /var/www/tovartech.org/html

4. Run:

   sudo bash setup-contact.sh

5. When prompted, enter the 16-character Google App Password for:

   noetovar5@gmail.com

   You may use the same valid Google App Password you are already using for the
   TovarBooks contact form if you choose, since both send through the same Gmail
   account. Do not send that password to anyone and do not put it in HTML.

6. The installer will:
   - install PHP
   - install php-mbstring
   - install Apache PHP support
   - install PHPMailer
   - create /etc/tovartech/contact-config.php
   - protect the config permissions
   - restart Apache

7. Browse to:

   https://tovartech.org/contact.html

8. Fill out the form and send a test message. It should arrive at:

   noetovar5@gmail.com

   Clicking Reply in Gmail should address the website visitor because their
   email is assigned as the Reply-To address.

OPTIONAL: ADD CONTACT TO YOUR EXISTING NAVIGATION
-------------------------------------------------
Add this link to your existing TovarTech navigation menus:

<a href="contact.html">Contact</a>

TROUBLESHOOTING
---------------
If you receive HTTP ERROR 500, immediately run:

sudo tail -n 50 /var/log/apache2/error.log

Check PHP syntax:

php -l send-contact.php

Expected result:
No syntax errors detected in send-contact.php

Check mbstring:

php -m | grep mbstring

Expected result:
mbstring

Check PHPMailer:

dpkg -l | grep phpmailer

Check whether Apache can read the secure config:

sudo -u www-data php -r "var_dump(is_readable('/etc/tovartech/contact-config.php'));"

Expected result:
bool(true)

Check Apache:

sudo systemctl status apache2 --no-pager

SECURITY NOTES
--------------
- Gmail credentials are stored outside the website document root.
- The form validates email addresses and message lengths.
- The form only permits predefined contact topics.
- A hidden honeypot field helps reject automated spam.
- Very fast and stale submissions are rejected.
- A session rate limit blocks rapid repeat submissions.
- Header injection characters are removed.
- Visitor input is HTML-escaped before being placed in the email.
- Do not accept passwords, private keys, or confidential data through this form.
