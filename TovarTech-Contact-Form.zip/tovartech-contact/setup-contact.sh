#!/usr/bin/env bash
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "Please run with sudo: sudo bash setup-contact.sh"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "Installing PHP, mbstring, Apache PHP support, and PHPMailer..."
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y php php-mbstring libapache2-mod-php libphp-phpmailer

a2enmod headers >/dev/null 2>&1 || true

read -rsp "Paste the 16-character Google App Password for noetovar5@gmail.com: " APPPASS
echo
APPPASS="${APPPASS// /}"
if [[ ${#APPPASS} -lt 16 ]]; then
  echo "That does not look like a Google App Password. No configuration was written."
  exit 1
fi

install -d -m 750 -o root -g www-data /etc/tovartech
cat > /etc/tovartech/contact-config.php <<CONFIG
<?php
return [
    'smtp_host' => 'smtp.gmail.com',
    'smtp_port' => 587,
    'smtp_user' => 'noetovar5@gmail.com',
    'smtp_pass' => '${APPPASS}',
    'from_email' => 'noetovar5@gmail.com',
    'from_name' => 'Tovar Tech Website',
    'to_email' => 'noetovar5@gmail.com',
];
CONFIG

chown root:www-data /etc/tovartech/contact-config.php
chmod 640 /etc/tovartech/contact-config.php
chmod 644 contact.html send-contact.php .htaccess
systemctl restart apache2

echo
echo "Tovar Tech contact form setup is complete."
echo "Open: https://tovartech.org/contact.html"
echo "Send yourself a test message from a different email address."
