<?php
declare(strict_types=1);

// Tovar Tech secure contact form processor
session_start();
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('X-Frame-Options: SAMEORIGIN');

function redirect_result(string $status): never {
    header('Location: contact.html?status=' . rawurlencode($status), true, 303);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method Not Allowed');
}

$now = time();
if (isset($_SESSION['last_contact']) && ($now - (int)$_SESSION['last_contact']) < 30) {
    redirect_result('error');
}

// Honeypot spam trap.
if (!empty($_POST['website'] ?? '')) {
    redirect_result('sent');
}

// Reject forms submitted unrealistically fast or forms left open for more than 2 hours.
$started = filter_input(INPUT_POST, 'form_started', FILTER_VALIDATE_INT);
if (!$started || ($now - $started) < 2 || ($now - $started) > 7200) {
    redirect_result('error');
}

$name = trim((string)($_POST['name'] ?? ''));
$email = trim((string)($_POST['email'] ?? ''));
$topic = trim((string)($_POST['subject'] ?? ''));
$message = trim((string)($_POST['message'] ?? ''));

$allowedTopics = [
    'Linux / Red Hat', 'Windows Server', 'SQL Server / Database',
    'Cloud / Virtualization', 'Automation / Scripting',
    'Training / Tutorial Question', 'Business / Collaboration',
    'Website Feedback', 'Other'
];

if ($name === '' || mb_strlen($name) > 100 ||
    !filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 160 ||
    !in_array($topic, $allowedTopics, true) ||
    $message === '' || mb_strlen($message) > 5000) {
    redirect_result('error');
}

$name = preg_replace('/[\r\n\x00-\x1F\x7F]+/u', ' ', $name) ?? $name;
$email = str_replace(["\r", "\n"], '', $email);
$topic = str_replace(["\r", "\n"], '', $topic);

$configFile = '/etc/tovartech/contact-config.php';
if (!is_file($configFile)) {
    error_log('Tovar Tech contact form: missing /etc/tovartech/contact-config.php');
    redirect_result('error');
}
$config = require $configFile;

$autoloaders = [
    __DIR__ . '/vendor/autoload.php',
    '/usr/share/php/libphp-phpmailer/autoload.php',
    '/usr/share/php/PHPMailer/autoload.php'
];
$loaded = false;
foreach ($autoloaders as $autoload) {
    if (is_file($autoload)) { require_once $autoload; $loaded = true; break; }
}
if (!$loaded) {
    error_log('Tovar Tech contact form: PHPMailer autoloader not found');
    redirect_result('error');
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host = $config['smtp_host'];
    $mail->SMTPAuth = true;
    $mail->Username = $config['smtp_user'];
    $mail->Password = $config['smtp_pass'];
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = (int)$config['smtp_port'];
    $mail->CharSet = 'UTF-8';
    $mail->Timeout = 15;

    $mail->setFrom($config['from_email'], $config['from_name']);
    $mail->addAddress($config['to_email'], 'Noe Tovar');
    $mail->addReplyTo($email, $name);

    $mail->Subject = '[Tovar Tech Contact] ' . $topic . ' - ' . $name;
    $safeName = htmlspecialchars($name, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $safeEmail = htmlspecialchars($email, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $safeTopic = htmlspecialchars($topic, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $safeMessage = nl2br(htmlspecialchars($message, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'));

    $mail->isHTML(true);
    $mail->Body = <<<HTML
<!doctype html><html><body style="font-family:Arial,sans-serif;color:#152337;background:#ffffff">
<div style="max-width:680px;margin:auto;border:1px solid #dbe8f3;border-radius:14px;overflow:hidden">
<div style="background:#071525;padding:20px 24px;color:white"><h2 style="margin:0;color:#35c9ff">New Tovar Tech Website Message</h2></div>
<div style="padding:24px">
<p><strong>Name:</strong> {$safeName}</p>
<p><strong>Email:</strong> {$safeEmail}</p>
<p><strong>Topic:</strong> {$safeTopic}</p>
<hr style="border:0;border-top:1px solid #dbe3ea">
<p><strong>Message:</strong></p><p>{$safeMessage}</p>
<hr style="border:0;border-top:1px solid #dbe3ea">
<p style="font-size:12px;color:#667085">Sent from the contact form at TovarTech.org. Reply to this email to respond directly to the visitor.</p>
</div></div></body></html>
HTML;
    $mail->AltBody = "New Tovar Tech Website Message\n\nName: $name\nEmail: $email\nTopic: $topic\n\nMessage:\n$message\n";
    $mail->send();
    $_SESSION['last_contact'] = $now;
    redirect_result('sent');
} catch (Exception $e) {
    error_log('Tovar Tech contact mail error: ' . $mail->ErrorInfo);
    redirect_result('error');
}
